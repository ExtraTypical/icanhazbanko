
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/box/box.mjs
import "dotenv/config";
import assert from "node:assert";
import BoxSDK from "box-node-sdk";
var Box = class {
  constructor() {
    assert(process.env.BOX_CLIENT_ID !== void 0, "Client ID is equal to undefined, meaning that there's something wrong with how the environmental variables are working.");
    assert(process.env.BOX_CLIENT_SECRET !== void 0, "Client Secret is equal to undefined, meaning that there's something wrong with how the environmental variables are working.");
    assert(process.env.BOX_PUBLIC_KEY_ID !== void 0, "Public Key ID is equal to undefined, meaning that there's something wrong with how the environmental variables are working.");
    assert(process.env.BOX_PRIVATE_KEY !== void 0, "Private Key is equal to undefined, meaning that there's something wrong with how the environmental variables are working.");
    assert(process.env.BOX_PASSPHRASE !== void 0, "Passphrase is equal to undefined, meaning that there's something wrong with how the environmental variables are working.");
    assert(process.env.BOX_USER_ID !== void 0, "User ID is equal to undefined, meaning that there's something wrong with how the environmental variables are working.");
    this.userID = process.env.BOX_USER_ID;
    this.enterpriseID = process.env.BOX_ENTERPRISE_ID;
    this.folderID = process.env.BOX_FOLDER_ID;
    this.config = {
      clientID: process.env.BOX_CLIENT_ID,
      clientSecret: process.env.BOX_CLIENT_SECRET,
      appAuth: {
        keyID: process.env.BOX_PUBLIC_KEY_ID,
        privateKey: process.env.BOX_PRIVATE_KEY,
        passphrase: process.env.BOX_PASSPHRASE
      }
    };
    this.sdk = new BoxSDK(this.config);
    this.client = this.sdk.getAppAuthClient("enterprise", this.enterpriseID);
  }
  async listItemsInFolder(folderID) {
    assert(folderID !== void 0, "folderID is undefined, meaning that it wasn't passed into this function");
    assert(typeof folderID === "string", "Typeof folderID is not string, actual type is ", typeof folderID);
    this.files = await this.client.folders.getItems(folderID, {
      usemarker: "false",
      fields: "name",
      offset: 0,
      limit: 25
    });
    return this.files;
  }
  async getFile(fileID) {
    assert(fileID !== void 0, "fileID is undefined, meaning that it wasn't passed into this function");
    assert(typeof fileID === "string", "Typeof fileID is not string, actual type is ", typeof fileID);
    const fileURL = await this.client.files.getDownloadURL(fileID);
    return fileURL;
  }
  async getRandomFile(randomNumber) {
    const response = {
      fileID: "",
      fileName: "",
      url: ""
    };
    assert(randomNumber !== void 0, "Random number is undefined, meaning that it wasn't properly passed to the function.");
    assert(typeof randomNumber === "number", "typeof randomNumber is not number, and this function requires it to be a number.");
    assert(this.files !== void 0, "File are undefined - make sure to call listItemsInFolder() first and that there are files in the requested folder.");
    assert(this.files.entries.length >= randomNumber, "Random number exceeds range of available files.");
    response.fileID = this.files?.entries[randomNumber]?.id;
    response.fileName = this.files?.entries[randomNumber]?.name;
    response.url = await this.getFile(response.fileID);
    return response;
  }
  async uploadFile(filename, stream, options) {
    const request = await this.client.files.uploadFile(this.folderID, filename, stream, options);
    return request;
  }
};
export {
  Box as default
};
