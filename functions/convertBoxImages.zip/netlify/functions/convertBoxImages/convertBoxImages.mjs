
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/box/box.mjs
import "dotenv/config";
import assert from "node:assert";
import BoxSDK from "box-node-sdk";
var Box = class {
  constructor() {
    assert(process.env.BOX_CLIENT_ID !== void 0, "Client ID is equal to undefined, meaning that there's something wrong with how the environmental variables are working.");
    assert(process.env.BOX_CLIENT_SECRET !== void 0, "Client Secret is equal to undefined, meaning that there's something wrong with how the environmental variables are working.");
    assert(process.env.BOX_PUBLIC_KEY_ID !== void 0, "Public Key ID is equal to undefined, meaning that there's something wrong with how the environmental variables are working.");
    assert(process.env.BOX_PRIVATE_KEY !== void 0, "Private Key is equal to undefined, meaning that there's something wrong with how the environmental variables are working.");
    assert(process.env.BOX_PASSPHRASE !== void 0, "Passphrase is equal to undefined, meaning that there's something wrong with how the environmental variables are working.");
    assert(process.env.BOX_USER_ID !== void 0, "User ID is equal to undefined, meaning that there's something wrong with how the environmental variables are working.");
    this.userID = process.env.BOX_USER_ID;
    this.enterpriseID = process.env.BOX_ENTERPRISE_ID;
    this.folderID = process.env.BOX_FOLDER_ID;
    this.config = {
      clientID: process.env.BOX_CLIENT_ID,
      clientSecret: process.env.BOX_CLIENT_SECRET,
      appAuth: {
        keyID: process.env.BOX_PUBLIC_KEY_ID,
        privateKey: process.env.BOX_PRIVATE_KEY,
        passphrase: process.env.BOX_PASSPHRASE
      }
    };
    this.sdk = new BoxSDK(this.config);
    this.client = this.sdk.getAppAuthClient("enterprise", this.enterpriseID);
  }
  async listItemsInFolder(folderID) {
    assert(folderID !== void 0, "folderID is undefined, meaning that it wasn't passed into this function");
    assert(typeof folderID === "string", "Typeof folderID is not string, actual type is ", typeof folderID);
    this.files = await this.client.folders.getItems(folderID, {
      usemarker: "false",
      fields: "name",
      offset: 0,
      limit: 25
    });
    return this.files;
  }
  async getFile(fileID) {
    assert(fileID !== void 0, "fileID is undefined, meaning that it wasn't passed into this function");
    assert(typeof fileID === "string", "Typeof fileID is not string, actual type is ", typeof fileID);
    const fileURL = await this.client.files.getDownloadURL(fileID);
    return fileURL;
  }
  async getRandomFile(randomNumber) {
    const response = {
      fileID: "",
      fileName: "",
      url: ""
    };
    assert(randomNumber !== void 0, "Random number is undefined, meaning that it wasn't properly passed to the function.");
    assert(typeof randomNumber === "number", "typeof randomNumber is not number, and this function requires it to be a number.");
    assert(this.files !== void 0, "File are undefined - make sure to call listItemsInFolder() first and that there are files in the requested folder.");
    assert(this.files.entries.length >= randomNumber, "Random number exceeds range of available files.");
    response.fileID = this.files?.entries[randomNumber]?.id;
    response.fileName = this.files?.entries[randomNumber]?.name;
    response.url = await this.getFile(response.fileID);
    return response;
  }
  async uploadFile(filename, stream, options) {
    const request = await this.client.files.uploadFile(this.folderID, filename, stream, options);
    return request;
  }
};

// netlify/functions/box/pictures.mjs
import convert from "heic-convert";
import Jimp from "jimp";
import assert2 from "node:assert";
var Picture = class {
  async convertHeicUrlToJpgBase64(url) {
    assert2(url !== void 0, "url is undefined, meaning that it was most likely passed incorrectly into this function.");
    const request = await fetch(url);
    const inputBuffer = await request.arrayBuffer();
    const outputBuffer = await convert({
      buffer: new Uint8Array(inputBuffer),
      format: "JPEG",
      quality: 1
    });
    const base64Jpg = outputBuffer.toString("base64");
    return base64Jpg;
  }
  async convertPngToJpgBase64(url) {
    try {
      const image = await Jimp.read({
        url
      });
      const jpgBuffer = await image.getBufferAsync(Jimp.MIME_JPEG);
      const base64Jpg = jpgBuffer.toString("base64");
      return base64Jpg;
    } catch (error) {
      console.error("Error converting image:", error);
      throw error;
    }
  }
  async handleFileType(file) {
    assert2(file !== void 0, "File is undefined, meaning that it wasn't passed correctly to this function.");
    switch (true) {
      case file.fileName.endsWith(".heic"): {
        return await this.convertHeicUrlToJpgBase64(file.url);
      }
      case file.fileName.endsWith(".png"): {
        return await this.convertPngToJpgBase64(file.url);
      }
      case file.fileName.endsWith(".jpg"): {
        const image = Jimp.read({
          url: file.url
        });
        const jpgBuffer = await image.getBufferAsync(Jimp.MIME_JPEG);
        const base64Jpg = jpgBuffer.toString("base64");
        return `data:image/jpeg;base64,${base64Jpg}`;
      }
      case file.fileName.endsWith(".jpeg"): {
        const image = Jimp.read({
          url: file.url
        });
        const jpgBuffer = await image.getBufferAsync(Jimp.MIME_JPEG);
        const base64Jpg = jpgBuffer.toString("base64");
        return `data:image/jpeg;base64,${base64Jpg}`;
      }
    }
  }
};

// netlify/functions/convertBoxImages/convertBoxImages.mjs
import assert3 from "node:assert";
import { Readable } from "node:stream";
var convertBoxImages_default = async (req) => {
  const box = new Box();
  const picture = new Picture();
  const heicFiles = await box.listItemsInFolder(process.env.BOX_HEIC_FOLDER_ID);
  const convertedFiles = await box.listItemsInFolder(process.env.BOX_FOLDER_ID);
  switch (true) {
    case heicFiles === void 0: {
      const error = "items returned as undefined, which means there was a problem with the call";
      console.error(error);
      return error;
    }
    case heicFiles.total_count === void 0: {
      const error = "items.total_count is equal to undefined, meaning that there's something wrong with the payload";
      console.error(error);
      return error;
    }
    case heicFiles?.total_count === 0: {
      const message = "Total count of files is equal to 0, so there are no photos to update.";
      console.log(message);
      return message;
    }
    case heicFiles?.entries === void 0: {
      const error = "Entries are undefined, meaning there's a problem with the payload";
      console.error(error);
      return error;
    }
  }
  switch (true) {
    case convertedFiles === void 0: {
      const error = "items returned as undefined, which means there was a problem with the call";
      console.error(error);
      return error;
    }
    case convertedFiles.total_count === void 0: {
      const error = "items.total_count is equal to undefined, meaning that there's something wrong with the payload";
      console.error(error);
      return error;
    }
  }
  const heicFilesArray = [];
  for (let i = 0; i < heicFiles?.entries?.length; i++) {
    let itemStruct = {
      type: "string",
      id: "string",
      etag: "string",
      name: "string"
    };
    if (heicFiles?.entries[i]?.name?.includes(".")) {
      let trimmedName = heicFiles?.entries[i].name.split(".")[0];
      heicFilesArray.push({
        id: heicFiles?.entries[i].id,
        name: heicFiles?.entries[i].name,
        trimmedName,
        type: heicFiles?.entries[i].type
      });
    }
  }
  const convertedFilesArray = [];
  if (convertedFiles.entries.length !== 0) {
    for (let i = 0; i < convertedFiles?.entries?.length; i++) {
      let itemStruct = {
        type: "string",
        id: "string",
        etag: "string",
        name: "string"
      };
      if (convertedFiles?.entries[i]?.name?.includes(".")) {
        let trimmedName = convertedFiles?.entries[i].name.split(".")[0];
        convertedFilesArray.push({
          id: convertedFiles?.entries[i].id,
          name: convertedFiles?.entries[i].name,
          trimmedName,
          type: convertedFiles?.entries[i].type
        });
      }
    }
  }
  const uniqueFiles = [];
  heicFilesArray.forEach((heicItem) => {
    const matchingConvertedItem = convertedFilesArray.find(
      (convertedItem) => heicItem.trimmedName === convertedItem.trimmedName
    );
    if (!matchingConvertedItem) {
      uniqueFiles.push(heicItem);
    }
  });
  for (let i = 0; i < uniqueFiles.length; i++) {
    let file = uniqueFiles[i];
    let base64img;
    let fileURL;
    switch (true) {
      case file?.name?.endsWith(".heic"): {
        fileURL = await box.getFile(file.id);
        assert3(fileURL !== void 0, "FileURL is undefined");
        base64img = await picture.convertHeicUrlToJpgBase64(fileURL);
        break;
      }
      case file?.name?.endsWith(".png"): {
        fileURL = await box.getFile(file.id);
        assert3(fileURL !== void 0, "FileURL is undefined");
        base64img = await picture.convertPngToJpgBase64(fileURL);
        break;
      }
      case (file?.name?.endsWith(".jpg") || file?.name?.endsWith(".jpeg")): {
        fileURL = await box.getFile(file.id);
        assert3(fileURL !== void 0, "FileURL is undefined");
        base64img = await picture.convertPngToJpgBase64(fileURL);
        break;
      }
      default: {
        console.error("File is an unrecognized type, will skip", file);
        break;
      }
    }
    var base64Buffer = Buffer.from(base64img, "base64");
    var stream = new Readable();
    stream._read = () => {
      stream.push(base64Buffer);
      stream.push(null);
    };
    var options = {
      content_length: Buffer.byteLength(base64img, "base64")
    };
    const newName = file.trimmedName + ".jpg";
    const result = await box.uploadFile(newName, base64Buffer, options);
    console.log(result);
  }
  return;
};
export {
  convertBoxImages_default as default
};
